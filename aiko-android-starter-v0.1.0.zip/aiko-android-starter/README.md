# AI.KO Android Starter 0.1.0

A native Android Jetpack Compose starter for the AI.KO personal intelligence system.

## Included now
- Native Android application shell.
- Home, Chat and Memory tabs.
- Local note/memory storage using Android SharedPreferences.
- Dark navy/purple/gold visual foundation.
- GitHub Actions workflow that builds a debug APK and uploads it as a workflow artifact.

## Important limitations
This is an initial app shell, not a complete AI assistant. It does not yet include:
- An online or offline AI model.
- Voice interaction.
- Android accessibility automation or broad device control.
- Cloud synchronisation.
- The full twelve-engine architecture.
- Encrypted memory storage.

The Chat screen is an integration placeholder. The Memory screen stores notes locally on the device. No network permission is requested by this starter.

## Build an APK using GitHub Actions
1. Upload the contents of this project into the root of your GitHub repository.
2. Commit and push to `main`.
3. Open the repository's **Actions** tab.
4. Select **Build AI.KO Android APK**.
5. Open the newest successful workflow run.
6. Under **Artifacts**, download `aiko-debug-apk`.
7. Extract the downloaded artifact ZIP on Android and install `app-debug.apk`.
8. If Android asks, allow your browser or file manager to install unknown apps for this installation.

A debug APK is for testing. A release build and signing process will be needed before wider distribution.

## Requirements
- Android 8.0 (API 26) or later.
- Internet is only required for downloading/building the project and future online integrations. The current app shell and local memory work offline after installation.
