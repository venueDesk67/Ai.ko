package com.aiko.app

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray

private val Navy = Color(0xFF100D20)
private val Panel = Color(0xFF1B1630)
private val Gold = Color(0xFFD9B66D)
private val Light = Color(0xFFF3F0FA)
private val Muted = Color(0xFFB9B2C9)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AikoApp() }
    }
}

@Composable
private fun AikoApp() {
    val context = LocalContext.current
    var selected by remember { mutableStateOf("Home") }
    var memories by remember { mutableStateOf(loadMemories(context)) }

    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Navy,
            surface = Panel,
            primary = Gold,
            onBackground = Light,
            onSurface = Light
        )
    ) {
        Column(
            modifier = Modifier.fillMaxSize().background(Navy).padding(18.dp)
        ) {
            Text("AI.KO", color = Gold, fontSize = 30.sp, fontWeight = FontWeight.Bold)
            Text("PERSONAL INTELLIGENCE SYSTEM", color = Muted, fontSize = 10.sp, letterSpacing = 2.sp)
            Spacer(Modifier.height(22.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Home", "Chat", "Memory").forEach { tab ->
                    FilterChip(
                        selected = selected == tab,
                        onClick = { selected = tab },
                        label = { Text(tab) }
                    )
                }
            }
            Spacer(Modifier.height(18.dp))
            when (selected) {
                "Home" -> HomeScreen(memories.size)
                "Chat" -> ChatScreen()
                "Memory" -> MemoryScreen(
                    memories = memories,
                    onAdd = { value ->
                        memories = memories + value
                        saveMemories(context, memories)
                    }
                )
            }
        }
    }
}

@Composable
private fun HomeScreen(memoryCount: Int) {
    Text("Welcome to your AI.KO foundation.", color = Light, fontSize = 21.sp, fontWeight = FontWeight.SemiBold)
    Spacer(Modifier.height(8.dp))
    Text("Your personal intelligence system starts here.", color = Muted)
    Spacer(Modifier.height(20.dp))
    InfoCard("LOCAL MEMORY", "$memoryCount saved entries", "Stored on this device.")
    Spacer(Modifier.height(12.dp))
    InfoCard("OPERATING MODE", "Offline-ready foundation", "This starter works without an internet connection.")
    Spacer(Modifier.height(12.dp))
    InfoCard("CURRENT STATUS", "Foundation prototype", "AI model, voice control and phone automation are not connected yet.")
    Spacer(Modifier.weight(1f))
    Text("AI.KO • VERSION 0.1.0", color = Gold, fontSize = 11.sp)
}

@Composable
private fun InfoCard(title: String, headline: String, detail: String) {
    Column(
        Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(16.dp)).padding(16.dp)
    ) {
        Text(title, color = Gold, fontSize = 10.sp, letterSpacing = 1.5.sp)
        Spacer(Modifier.height(6.dp))
        Text(headline, color = Light, fontWeight = FontWeight.SemiBold, fontSize = 17.sp)
        Text(detail, color = Muted, fontSize = 13.sp)
    }
}

@Composable
private fun ChatScreen() {
    Text("AI.KO conversation", color = Light, fontSize = 21.sp, fontWeight = FontWeight.SemiBold)
    Spacer(Modifier.height(12.dp))
    InfoCard(
        "CHAT FOUNDATION",
        "The conversation interface is ready for integration.",
        "This version does not contain an AI model yet. We will connect an online model and add an optional local model in later development."
    )
}

@Composable
private fun MemoryScreen(memories: List<String>, onAdd: (String) -> Unit) {
    var entry by remember { mutableStateOf("") }
    Text("Personal memory", color = Light, fontSize = 21.sp, fontWeight = FontWeight.SemiBold)
    Text("Add notes stored locally on this phone.", color = Muted, fontSize = 13.sp)
    Spacer(Modifier.height(12.dp))
    Row(verticalAlignment = Alignment.CenterVertically) {
        BasicTextField(
            value = entry,
            onValueChange = { entry = it },
            modifier = Modifier.weight(1f).background(Panel, RoundedCornerShape(12.dp)).padding(14.dp),
            textStyle = androidx.compose.ui.text.TextStyle(color = Light, fontSize = 14.sp),
            decorationBox = { inner ->
                if (entry.isEmpty()) Text("Write a memory...", color = Muted)
                inner()
            }
        )
        Spacer(Modifier.width(8.dp))
        Button(
            onClick = {
                val clean = entry.trim()
                if (clean.isNotEmpty()) {
                    onAdd(clean)
                    entry = ""
                }
            },
            enabled = entry.isNotBlank()
        ) { Text("Save") }
    }
    Spacer(Modifier.height(14.dp))
    if (memories.isEmpty()) {
        Text("No memories saved yet.", color = Muted)
    } else {
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(memories.reversed()) { memory ->
                Text(memory, color = Light, modifier = Modifier.fillMaxWidth()
                    .background(Panel, RoundedCornerShape(12.dp)).padding(14.dp))
            }
        }
    }
}

private fun loadMemories(context: Context): List<String> {
    val raw = context.getSharedPreferences("aiko_local", Context.MODE_PRIVATE)
        .getString("memories", "[]") ?: "[]"
    return try {
        val array = JSONArray(raw)
        (0 until array.length()).map { array.getString(it) }
    } catch (_: Exception) { emptyList() }
}

private fun saveMemories(context: Context, memories: List<String>) {
    val array = JSONArray()
    memories.forEach { array.put(it) }
    context.getSharedPreferences("aiko_local", Context.MODE_PRIVATE)
        .edit().putString("memories", array.toString()).apply()
}
